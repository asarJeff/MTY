<?xml version="1.0" encoding="utf-8"?>
<ProcessExtensionScenario xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://sap.com/ByD/PDI/ProcessExtensionScenarioDefinition">
  <Name xmlns="">BusinessPartnerRelationship</Name>
  <BoNameSpace xmlns="">http://sap.com/xi/AP/FO/BusinessPartnerRelationship/Global</BoNameSpace>
  <BoName xmlns="">BusinessPartnerRelationship</BoName>
  <BoNodeName xmlns="">Root</BoNodeName>
  <ExtensionScenarioList xmlns="">
    <ExtensionScenario>
      <scenario_name>0CE4C76A254FFD6C03382EDB1CCA9C</scenario_name>
      <scenario_description>QueryBusinessPartnerContactPersonInformation ( Service name ManageCustomerIn and operation name MaintainBundle_V1 and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND_EXTEXP_MIG</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>MAINTAIN_BUNDLE_V1</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_MAINT_REQ_MSG_IN_V1</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>113FA24FB68CCEC5A6ADD3BB6B8F70</scenario_name>
      <scenario_description>QueryBusinessPartner-RelationshipInformation ( Service name QueryCustomerIn and operation name FindByElements and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_ELEMENTS</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT_NODE</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>23FFC181E237E490A6977F59982739</scenario_name>
      <scenario_description>QueryBusinessPartnerContactPersonInformation ( Service name QueryCustomerIn and operation name FindByElements and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_ELEMENTS</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>318AC0AFF2B134A4A1C78844001616</scenario_name>
      <scenario_description>QueryBusinessPartnerContactPersonInformation ( Service name QueryCustomerIn and operation name FindByIdentification and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_IDENTIFICATION</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN_FI</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>348C16DB145DA187BE48448F0C470B</scenario_name>
      <scenario_description>QueryBusinessPartner-RelationshipInformation ( Service name QueryCustomerIn and operation name FindByIdentification and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_IDENTIFICATION</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN_FI</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT_NODE</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>38558AF9935C758CF1BEE3BFC9C0E8</scenario_name>
      <scenario_description>QueryBusinessPartner-RelationshipInformation ( Service name QueryCustomerIn and operation name FindByCommunicationData and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_COMMU_DATA</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN_FC</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT_NODE</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>3939CCB9EC6BF90AD516E0BC54ADC2</scenario_name>
      <scenario_description>Business Partner Relationship Replication - Root ( Service name BusinessPartnerRelationshipReplicationIn and operation name ReplicateBusinessPartnerRelationship and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND_EXTEXP_MIG</service_interface_type>
      <is_selected>true</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA_REL</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_REL_MDG_REPL_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>41E61D274A967A418D31078DEA8F16</scenario_name>
      <scenario_description>Business Partner Relationship Replication - Root ( Service name BusinessPartnerRelationshipReplicationSelfInitiatedOut and operation name RequestBusinessPartnerRelationshipReplication and direction Outbound )</scenario_description>
      <service_interface_type>OUTBOUND</service_interface_type>
      <is_selected>true</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA_REL</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name />
          <target_bo_node_name />
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_REL_MDG_REPL_MSG_OUT</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>478AAE10251A35844FD29E26B23FB7</scenario_name>
      <scenario_description>Business Partner Sales Arrangement Partner Function ERP - Business Partner Relationship ( Service name BusinessPartnerERPReplicationOut and operation name ReplicateBusinessPartner and direction Outbound )</scenario_description>
      <service_interface_type>OUTBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name />
          <target_bo_node_name />
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_ERP_REPL_OUT</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT_TN</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>7343D6AA2C6102A2AD82315F78483C</scenario_name>
      <scenario_description>Business Partner Sales Arrangement Partner Function - Business Partner Relationship ( Service name BusinessPartnerReplicationIn and operation name ReplicateBusinessPartner and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND_EXTEXP_MIG</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_MDG_REPL_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>80B196ACFF1D17EFDD9E17526DB5C7</scenario_name>
      <scenario_description>QueryBusinessPartnerContactPersonInformation ( Service name QueryCustomerIn and operation name FindByCommunicationData and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_COMMU_DATA</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CUST_QUERY_RSP_MSG_IN_FC</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>8B564E94A476ADF01F7309DCA17F20</scenario_name>
      <scenario_description>Business Partner Sales Arrangement Partner Function ERP - Business Partner Relationship ( Service name BusinessPartnerERPReplicationIn and operation name ReplicateBusinessPartner and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_ERP_REPL_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT_TN</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>ADB3C979473EBCC81E2FD94ACA90E4</scenario_name>
      <scenario_description>Business Partner Replication ERP - Contact Relationship Information ( Service name BusinessPartnerERPReplicationOut and operation name ReplicateBusinessPartner and direction Outbound )</scenario_description>
      <service_interface_type>OUTBOUND</service_interface_type>
      <is_selected>true</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name />
          <target_bo_node_name />
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_ERP_REPL_OUT</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>B59C5A7A5BDA4704F9B599FEA5306B</scenario_name>
      <scenario_description>Business Partner Replication ERP - Contact Relationship Information ( Service name BusinessPartnerERPReplicationIn and operation name ReplicateBusinessPartner and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>true</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_ERP_REPL_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>BA525C8542DD19E2AA61903910F548</scenario_name>
      <scenario_description>Business Partner Sales Arrangement Partner Function - Business Partner Relationship ( Service name BusinessPartnerReplicationSelfInitiatedOut and operation name RequestBusinessPartnerReplication and direction Outbound )</scenario_description>
      <service_interface_type>OUTBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUPA</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name />
          <target_bo_node_name />
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_MDG_REPL_MSG_OUT</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>BFA53D6DBB5032B31F497D0E9B8B85</scenario_name>
      <scenario_description>Manage Business Partner Relationship Information ( Service name ManageContactIn and operation name MaintainBundle and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>MAINTAIN_BUNDLE</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CONTACT_MAINT_REQ_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>BPM_BPR_TO_BUPA_EMP_RESP</scenario_name>
      <scenario_description>Business Partner Relationship -&gt; Account Team</scenario_description>
      <service_interface_type />
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>Business Partner Relationship - General Information --&gt; Business Partner - Team</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_TMPL</target_bo_name>
          <target_bo_node_name>CURR_EMPLOYEE_RESPONSIBLE</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BPR_TO_BUPA_EMP_RESP</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT-BUSINESS_PARTNER_TMPL-CURR_EMPLOYEE_RESPONSIBLE</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>COD_CONTACT_2_TG_CONTACT_SEL</scenario_name>
      <scenario_description>Contact - General Information to Target Group - Contact Selection</scenario_description>
      <service_interface_type />
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>Business Partner Relationship - General Information --&gt; Target Group - Target Group Selection Conditions for Account Contact</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>TARGET_GROUP</target_bo_name>
          <target_bo_node_name>CONTACT_SEL_CONDITIONS</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>COD_ACC_2_TG_CONTACT_SEL</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT-TARGET_GROUP-CONTACT_SEL_CONDITIONS</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
        <Flow>
          <bo_connection_order>2</bo_connection_order>
          <bo_connection_description>Business Partner - General Information --&gt; Target Group - Target Group Selection Conditions for Account Contact</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_TMPL</source_bo_name>
          <source_bo_node_name>COMMON</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>TARGET_GROUP</target_bo_name>
          <target_bo_node_name>CONTACT_SEL_CONDITIONS</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>COD_ACC_2_TG_ACC_SEL</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_TMPL-COMMON-TARGET_GROUP-CONTACT_SEL_CONDITIONS</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>CRM_BUPA_REL_2_BUY_CTR</scenario_name>
      <scenario_description>Business Partner Relationship - Root to Buying Center - Relationship</scenario_description>
      <service_interface_type />
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>Business Partner Relationship - General Information --&gt; Buying Center - Relationship</bo_connection_description>
          <source_bo_name>BUSINESS_PARTNER_RELATIONSHIP</source_bo_name>
          <source_bo_node_name>ROOT</source_bo_node_name>
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUYING_CENTER</target_bo_name>
          <target_bo_node_name>RELATIONSHIP</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>CRM_BUPA_REL_2_BUY_CTR</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT-BUYING_CENTER-RELATIONSHIP</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>DD4020D829E88E3AF7F584D29C2FE8</scenario_name>
      <scenario_description>Manage Business Partner Relationship Information ( Service name QueryContactIn and operation name FindByElements and direction Outbound )</scenario_description>
      <service_interface_type>INBOUND</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>FIND_BY_ELEMENTS</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_CONTACT_QUERY_RSP_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
    <ExtensionScenario>
      <scenario_name>E9AA37A01087738B2CB61B8B12DAB5</scenario_name>
      <scenario_description>Replicate Business Partner - Relationship ( Service name BusinessPartnerDataManagementBusinessPartnerReplicationIn and operation name ReplicateBusinessPartner and direction Inbound )</scenario_description>
      <service_interface_type>INBOUND_MIG</service_interface_type>
      <is_selected>false</is_selected>
      <bo_connections>
        <Flow>
          <bo_connection_order>1</bo_connection_order>
          <bo_connection_description>REPLICATE_BUSINESS_PARTNER</bo_connection_description>
          <source_bo_name />
          <source_bo_node_name />
          <is_source_hidden>false</is_source_hidden>
          <target_bo_name>BUSINESS_PARTNER_RELATIONSHIP</target_bo_name>
          <target_bo_node_name>ROOT</target_bo_node_name>
          <is_target_hidden />
          <reference_field_keys>
            <reference_field_key>
              <reference_field_bundle_key>BPM_BUPA_REPL_REQ_MSG_IN</reference_field_bundle_key>
              <reference_field_name>BUSINESS_PARTNER_RELATIONSHIP-ROOT</reference_field_name>
            </reference_field_key>
          </reference_field_keys>
        </Flow>
      </bo_connections>
    </ExtensionScenario>
  </ExtensionScenarioList>
</ProcessExtensionScenario>